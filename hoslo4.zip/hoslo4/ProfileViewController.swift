//
//  ProfileViewController.swift
//  hoslo3
//
//  Created by Goktan on 10.04.2022.
//

import UIKit
import FirebaseAuth
import FBSDKLoginKit
import GoogleSignIn
import Firebase

class ProfileViewController: UIViewController {
    
    
    var user: User?
    var posts = [Post]()
    var userId: String?
    
    let cellId = "cellId"
    let homePostCellId = "homePostCellId"
    
    var isGridView: Bool = true

    
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    @IBAction func logout(_ sender: Any) {
        FBSDKLoginKit.LoginManager().logOut()
        GIDSignIn.sharedInstance.signOut()
        
        do {
            
            
            
            
            
            
            
            try FirebaseAuth.Auth.auth().signOut()

            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav, animated: true)
        }
        catch {
            print("Failed to log out")
        }
        
        
        
    }
    
    

    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
