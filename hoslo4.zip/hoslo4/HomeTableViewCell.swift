//
//  HomeTableViewCell.swift
//  KD Tiktok-Clone
//
//  Created by Sam Ding on 9/8/20.
//  Copyright © 2020 Kaishan. All rights reserved.
//

import UIKit
import AVFoundation
import MarqueeLabel
import FirebaseDatabase
import FirebaseAuth
import AVKit
protocol HomeCellNavigationDelegate: class {
    // Navigate to Profile Page
    func navigateToProfilePage(user:User, name: String)
    func navigateToComments(post:VideoPost)
}

class HomeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var sdvideoview: UIView!
    @IBOutlet weak var ultimateprofeimg: UIImageView!
    // MARK: - UI Components
    var playerView: VideoPlayerView!
    @IBOutlet weak var nameBtn: UIButton!
    @IBOutlet weak var captionLbl: UILabel!
    @IBOutlet weak var musicLbl: MarqueeLabel!
    
    var ayi = 2
   // @IBOutlet weak var profileImgView: UIImageView!{
      //  didSet{
          //  ultimateprofeimg.isUserInteractionEnabled = true
        //    let tapGesture = UITapGestureRecognizer(target: self, action: #selector(navigateToProfilePage))
       //     ultimateprofeimg.addGestureRecognizer(tapGesture)
     //   }
  //  }
 //   @IBOutlet weak var followBtn: UIButton!
    @IBOutlet weak var likeBtn: UIButton!
    
    
    @IBOutlet weak var seenbutton: UIButton!
    
    
    @IBOutlet weak var seencountlabel: UILabel!
    
    @IBOutlet weak var likeCountLbl: UILabel!
    @IBOutlet weak var commentBtn: UIButton!
    @IBOutlet weak var commentCountLbl: UILabel!
    @IBOutlet weak var shareBtn: UIButton!
    
    
//    @IBOutlet weak var musicBtn: UIButton!
    @IBOutlet weak var shareCountLbl: UILabel!
    @IBOutlet weak var pauseImgView: UIImageView!{
        didSet{
            pauseImgView.alpha = 0
        }
    }
    var likecont = 1
    var commentcont = 1
  //  var sharecont = 1
    var cont = 1

    
    // MARK: - Variables
    private(set) var isPlaying = false
    private(set) var liked = false
    var post: VideoPost?
    weak var delegate: HomeCellNavigationDelegate?
    
    // MARK: LIfecycles
    override func prepareForReuse() {
        super.prepareForReuse()
        playerView.cancelAllLoadingRequest()
        resetViewsForReuse()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        shareBtn.isHidden = true
        shareCountLbl.isHidden = true
        musicLbl.isHidden = true
        ultimateprofeimg.makeRounded(color: .white, borderWidth: 1)
       // profileImgView.makeRounded(color: .white, borderWidth: 1)
    //    followBtn.makeRounded(color: .clear, borderWidth: 0)
      //  musicBtn.makeRounded(color: .clear, borderWidth: 0)
     //   musicBtn.isHidden = true
      //  profileImgView.isHidden = true
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        playerView = VideoPlayerView(frame: self.contentView.frame)
    //    musicLbl.holdScrolling = true
   //     musicLbl.animationDelay = 0
        
        
        contentView.addSubview(playerView)
        contentView.sendSubviewToBack(playerView)
        
        
     //   let eyeGesture = UITapGestureRecognizer(target: self, action: #selector(eyeplus))
     //   self.contentView.addGestureRecognizer(eyeGesture)

        
        let pauseGesture = UITapGestureRecognizer(target: self, action: #selector(handlePause))
        self.contentView.addGestureRecognizer(pauseGesture)
        
        let likeDoubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleLikeGesture(sender:)))
        likeDoubleTapGesture.numberOfTapsRequired = 2
        self.contentView.addGestureRecognizer(likeDoubleTapGesture)
        
        pauseGesture.require(toFail: likeDoubleTapGesture)
    }
    
    
    func configure(post: VideoPost){
        self.post = post
        nameBtn.setTitle( post.username, for: .normal)
        nameBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
     //   musicLbl.text = post.music + "   " + post.music + "   " + post.music + "   "// Long enough to enable scrolling
        
       
    
        ultimateprofeimg.sd_setImage(with: URL(string: post.profileimageurl))
        
        
        
        
        
        captionLbl.text = post.caption
        likeCountLbl.text = "\(post.likeCount)"
        commentCountLbl.text = "\(post.commentCount)"
        shareCountLbl.text = "\(post.shareCount)"
        
       
        
     //   print("GOGOGKGOKGOGKGOGGG")
      //  print(post.commentCount)
      //  print(commentCountLbl.text)
        
        
        
        ultimateprofeimg.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(navigateToProfilePage))
        ultimateprofeimg.addGestureRecognizer(tapGesture)
        
        
        print("ULTİMATE İNASNZOR")
        print(post.videoURL!)
        print(post.videoFileExtension)
        print(post.videoWidth)
        print(post.video)
        print(post.videoHeight)
        playerView.configure(url: post.videoURL!, fileExtension: post.videoFileExtension, size: (post.videoWidth, post.videoHeight))
        
        
        
        var  seen = post.eyeCount
        
        seen += 1
        seencountlabel.text = "\(seen)"
        
        
        print("////////////////////////")
        print(seen)
        
        
        
        let userDic:[String: Any] = ["userId": post.useruid,
                                     "bio ": post.bio,
                                     "followersCount": post.followcount,
                                     "followingCount": post.followingcount,
                                     "postsCount": post.followingcount,
                                     "profileImageUrl": post.profileimageurl,
                                     "username": post.username
                                    ]
        
        
        
        let StringPostID = "\(post.id)"
        let  StringvideoURL = "\(post.videoURL)"
        
        
        
        

        var values = ["imageUrl":post.imageURL, "caption": post.caption,"id":StringPostID,"videoURL":StringvideoURL,"video":post.video,"videoFileExtension":post.videoFileExtension,"likeCount":post.likeCount,"shareCount":post.shareCount,"commentCount":post.commentCount,"eyeCount":seen,"user":userDic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
        
        //dtayag kullan
        
        
       
    
            
            
        
        
       
     
        
        
 
        
        
        
        
        
        
        
        
        
        
        
    }
   
    
    
    func replay(){
        if !isPlaying {
            playerView.replay()
            play()
        }
    }
    
    func play() {
        if !isPlaying {
            playerView.play()
            
            
            guard let post = post else { return }

            
           
            
            
            
            
            
         //   musicLbl.holdScrolling = false
            isPlaying = true
        }
    }
    
    func pause(){
        if isPlaying {
            playerView.pause()
           // musicLbl.holdScrolling = true
            isPlaying = false
        }
    }
    
    @objc func handlePause(){
        if isPlaying {
            // Pause video and show pause sign
            UIView.animate(withDuration: 0.075, delay: 0, options: .curveEaseIn, animations: { [weak self] in
                guard let self = self else { return }
                self.pauseImgView.alpha = 0.35
                self.pauseImgView.transform = CGAffineTransform.init(scaleX: 0.45, y: 0.45)
            }, completion: { [weak self] _ in
                self?.pause()
            })
        } else {
            // Start video and remove pause sign
            UIView.animate(withDuration: 0.075, delay: 0, options: .curveEaseInOut, animations: { [weak self] in
                guard let self = self else { return }
                self.pauseImgView.alpha = 0
            }, completion: { [weak self] _ in
                self?.play()
                self?.pauseImgView.transform = .identity
            })
        }
    }
    
    func resetViewsForReuse(){
        likeBtn.tintColor = .white
        pauseImgView.alpha = 0
    }
    
    
    // MARK: - Actions
    // Like Video Actions
    @IBAction func like(_ sender: Any) {
        
   
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let postId = post?.id ?? ""
        
        let postuserId = post?.useruid ?? ""
        
        
        let likedme = "liked your post"
        
        let values = ["text": likedme , "creationDate": Date().timeIntervalSince1970, "uid": uid] as [String: Any]
       
        
        Database.database().reference().child("notifications").child(postuserId).childByAutoId().updateChildValues(values) { (err, ref) in
            if let err = err {
                print("Failed to insert notification:", err)
                return
            }
         //   self.containerView.clearCommentTextField()
            print("Successfully inserted notificatiom")
        }
        
        
        
        
        
        
        
        
        
    //    if !liked {
            
            if likecont % 2 == 0 {
            
          print(liked)
            
            guard let post = post else { return }
            
            var likecounttt = post.likeCount
            likecounttt -= 1
            likeCountLbl.text = "\(likecounttt)"
            
           
            
            
            let userDic:[String: Any] = ["userId": post.useruid,
                                         "bio ": post.bio,
                                         "followersCount": post.followcount,
                                         "followingCount": post.followingcount,
                                         "postsCount": post.followingcount,
                                         "profileImageUrl": post.profileimageurl,
                                         "username": post.username
                                        ]
            
            
            
            let StringPostID = "\(post.id)"
            let  StringvideoURL = "\(post.videoURL)"
            
            
            
            

                var values = ["imageUrl":post.imageURL, "caption": post.caption,"id":StringPostID,"videoURL":StringvideoURL,"video":post.video,"videoFileExtension":post.videoFileExtension,"likeCount":likecounttt,"shareCount":post.shareCount,"commentCount":post.commentCount,"visionCount":post.eyeCount,"user":userDic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
            
            //dtayag kullan
            
            let feedPostRefperUser = Database.database().reference().child("VideoFeedPosts").child(post.id)
            
            feedPostRefperUser.updateChildValues(values) { (err, ref) in
                       if let err = err {
                           // self.navigationItem.rightBarButtonItem?.isEnabled = true
                          print("Failed to save post to DB", err)
                            return
                        }
            
           }
                likecont += 1
            
            
        //Database.fetchUserWithUID(uid: uid) { user in
                
                
               
            cont += 1
            
                
                
              //  values["user"] = userDic
            
            
            
           // likeVideo()
        } else {
           
            guard let post = post else { return }
            var likecounttt = post.likeCount
            likecounttt += 1
            likeCountLbl.text = "\(likecounttt)"
            
            
            
            
            let userDic:[String: Any] = ["userId": post.useruid,
                                         "bio ": post.bio,
                                         "followersCount": post.followcount,
                                         "followingCount": post.followingcount,
                                         "postsCount": post.followingcount,
                                         "profileImageUrl": post.profileimageurl,
                                         "username": post.username
                                        ]
            
            
            
            let StringPostID = "\(post.id)"
            let  StringvideoURL = "\(post.videoURL)"
            
            
            
            

            var values = ["imageUrl":post.imageURL, "caption": post.caption,"id":StringPostID,"videoURL":StringvideoURL,"video":post.video,"videoFileExtension":post.videoFileExtension,"likeCount":likecounttt,"shareCount":post.shareCount,"commentCount":post.commentCount,"visionCount":post.eyeCount,"user":userDic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
            
            //dtayag kullan
            
            let feedPostRefperUser = Database.database().reference().child("VideoFeedPosts").child(post.id)
            
            feedPostRefperUser.updateChildValues(values) { (err, ref) in
                       if let err = err {
                           // self.navigationItem.rightBarButtonItem?.isEnabled = true
                          print("Failed to save post to DB", err)
                            return
                        }
            
           }
            
            
            
            cont += 1
            likecont += 1

            liked = false
            likeBtn.tintColor = .white
        }
        
    }
    
    @objc func likeVideo(){
        if !liked {
            liked = true
            
           
            
            
            
            
            
            likeBtn.tintColor = .red
        }
        
       // liked = true
        
        
        
    }
    
    // Heart Animation with random angle
    @objc func handleLikeGesture(sender: UITapGestureRecognizer){
        let location = sender.location(in: self)
        let heartView = UIImageView(image: UIImage(systemName: "heart.fill"))
        heartView.tintColor = .red
        let width : CGFloat = 110
        heartView.contentMode = .scaleAspectFit
        heartView.frame = CGRect(x: location.x - width / 2, y: location.y - width / 2, width: width, height: width)
        heartView.transform = CGAffineTransform(rotationAngle: CGFloat.random(in: -CGFloat.pi * 0.2...CGFloat.pi * 0.2))
        self.contentView.addSubview(heartView)
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 3, options: [.curveEaseInOut], animations: {
            heartView.transform = heartView.transform.scaledBy(x: 0.85, y: 0.85)
        }, completion: { _ in
            UIView.animate(withDuration: 0.4, delay: 0.1, usingSpringWithDamping: 0.8, initialSpringVelocity: 3, options: [.curveEaseInOut], animations: {
                heartView.transform = heartView.transform.scaledBy(x: 2.3, y: 2.3)
                heartView.alpha = 0
            }, completion: { _ in
                heartView.removeFromSuperview()
            })
        })
        likeVideo()
    }
    
    @IBAction func comment(_ sender: Any) {
        
        guard let post = post else { return }

        
      ///  if commentcont % 2 == 0 {
            print("LLLLLL")
            
          

         //   var aga = Int(commentCountLbl.text ?? "") ?? 0
            
         //   aga -= 1
       //     commentCountLbl.text = "\(aga)"
       //     print(aga)
            
            
         //   var com = post.commentCount
        //    com -= 1
         
        //    let userDic:[String: Any] = ["userId": post.useruid,
                  //                       "bio ": post.bio,
                  //                       "followersCount": post.followcount,
                  //                       "followingCount": post.followingcount,
                 //                        "postsCount": post.followingcount,
                //                         "profileImageUrl": post.profileimageurl,
            //                             "username": post.username
            //                            ]
         //   let StringPostID = "\(post.id)"
        //    let  StringvideoURL = "\(post.videoURL)"
        //    var values = ["imageUrl":post.imageURL, "caption": post.caption,"id":StringPostID,"videoURL":StringvideoURL,"video":post.video,"videoFileExtension":post.videoFileExtension,"likeCount":post.likeCount,"shareCount":post.shareCount,"commentCount":com,"eyeCount":post.eyeCount,"user":userDic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
      //      let feedPostRefperUser = Database.database().reference().child("FeedPosts").child(post.id)
            
        //    feedPostRefperUser.updateChildValues(values) { (err, ref) in
         //              if let err = err {
                           // self.navigationItem.rightBarButtonItem?.isEnabled = true
         //                 print("Failed to save post to DB", err)
                     //       return
                    //    }
            
         //  }
            
           // commentcont += 1
            
            
   //     }
  //  else{
  //      print("XXXXXXXXX")
        

     //   var com = post.commentCount
    //   com += 1
        
    //    var aga = Int(commentCountLbl.text ?? "") ?? 0
        
      //  print(aga)
        
     //   aga += 1
    //    commentCountLbl.text = "\(aga)"
        
        
        
        
        
        
     //   let userDic:[String: Any] = ["userId": post.useruid,
                     //                "bio ": post.bio,
                      //               "followersCount": post.followcount,
                    //                 "followingCount": post.followingcount,
                        //             "postsCount": post.followingcount,
                        //             "profileImageUrl": post.profileimageurl,
                       //              "username": post.username
                      //              ]
    //    let StringPostID = "\(post.id)"
     //   let  StringvideoURL = "\(post.videoURL)"
   //     var values = ["imageUrl":post.imageURL, "caption": post.caption,"id":StringPostID,"videoURL":StringvideoURL,"video":post.video,"videoFileExtension":post.videoFileExtension,"likeCount":post.likeCount,"shareCount":post.shareCount,"commentCount":com,"eyeCount":post.eyeCount,"user":userDic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
  //      let feedPostRefperUser = Database.database().reference().child("FeedPosts").child(post.id)
        
        
        
        
      //  feedPostRefperUser.updateChildValues(values) { (err, ref) in
        //           if let err = err {
                       // self.navigationItem.rightBarButtonItem?.isEnabled = true
             //         print("Failed to save post to DB", err)
              //          return
                //    }
            
        
     //  }
        
        
    //    commentcont += 1
        
        
        
 //   }
        
       // let commentsController = CommentsController(collectionViewLayout: UICollectionViewFlowLayout())
      //  commentsController.post = post
       // commentsController.hidesBottomBarWhenPushed = true
       // navigationController?.pushViewController(commentsController, animated: true)
        
        delegate?.navigateToComments(post:post)
        
        
      //  CommentPopUpView.init().show()
    }
    
    @IBAction func share(_ sender: Any) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    @objc func navigateToProfilePage(){
        guard let post = post else { return }
        
        let dic = ["userId":post.useruid,"bio":post.bio,"followersCount":post.followcount,"followingCount":post.followingcount,"postsCount":post.postcount,"profileImageUrl":post.profileimageurl,"username":post.username] as [String : Any]
        let uuser = User(uid: post.useruid, dictionary: dic)
        
        UserProfileController().userId = post.useruid
        UserProfileController().user = uuser
        
        
        
        delegate?.navigateToProfilePage(user:uuser, name: post.useruid)
    }
    
    
    
    
}
