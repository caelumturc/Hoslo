//
//  challengescell.swift
//  hoslo4
//
//  Created by Goktan on 6.05.2022.
//

import UIKit

class challengescell: UITableViewCell {

    @IBOutlet weak var imagchallange: UIImageView!
    @IBOutlet weak var namechalange: UILabel!
    
    @IBOutlet weak var textchallange: UILabel!
    
    @IBOutlet weak var acceptbutton: UIButton!
    
    @IBOutlet weak var viewbutton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func acceptbuttonchal(_ sender: Any) {
        
        
    }
    @IBAction func viewbuttonchal(_ sender: Any) {
        
        
        
    }
    
    func setuppp(challange:Comment){
    
        
        
        viewbutton.makeRounded(color: .gray, borderWidth: 1)
        acceptbutton.makeRounded(color: .systemTeal, borderWidth: 1)
        imagchallange.makeRounded(color: .white, borderWidth: 1)
     

        namechalange.text = challange.user.username
        textchallange.text = challange.text
        imagchallange.sd_setImage(with: URL(string: challange.user.profileImageUrl))
        
        
       
       
        
        
        
        
        
    }
    
    
    
}
