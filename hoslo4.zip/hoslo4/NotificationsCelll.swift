//
//  NotificationsCelll.swift
//  hoslo4
//
//  Created by Goktan on 4.05.2022.
//

import UIKit

class NotificationsCelll: UITableViewCell {

    @IBOutlet weak var imagnotifi: UIImageView!
    
    
    @IBOutlet weak var namenotifi: UILabel!
    
    
    @IBOutlet weak var textnotifi: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    
    
    func setupp(notifi:Comment){
    
        
        
     //   viewbutton.makeRounded(color: .gray, borderWidth: 1)
    //    acceptbutton.makeRounded(color: .systemTeal, borderWidth: 1)
        imagnotifi.makeRounded(color: .white, borderWidth: 1)
        
        
        
        
        print(notifi.user.username)
        print(notifi.text)
        print(notifi.user.profileImageUrl)

        namenotifi.text = notifi.user.username
        textnotifi.text = notifi.text
        imagnotifi.sd_setImage(with: URL(string: notifi.user.profileImageUrl))
        
        
       
       
        
        
        
        
        
    }
    

}
