//
//  LoginViewController.swift
//  social wawes
//
//  Created by Goktan on 14.01.2022.
//

import UIKit
import FirebaseAuth
import FBSDKLoginKit
import GoogleSignIn
import JGProgressHUD


class LoginViewController: UIViewController {

   
        
        override var preferredStatusBarStyle: UIStatusBarStyle { return .lightContent }

        
    //    let logoContrainerView: UIView = {
    //        let view = UIView()
    //        let image = UIImage(named: "hoslologox")!
    //        let tintImage = image.withRenderingMode(.alwaysTemplate)
    //        let logoImageView = UIImageView(image: tintImage)
          //  logoImageView.tintColor = .label
            //let logoImageView = UIImageView(image: #imageLiteral(resourceName: "logo"))
     //       logoImageView.contentMode = .scaleAspectFill
     //       view.addSubview(logoImageView)
      //      logoImageView.anchor(top: nil, left: nil, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 300, height: 75)
         //   logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
         //   logoImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
         //   return view
      //  }()
    
    
    let logoContrainerView: UIImageView = {
       
        let image = UIImage(named: "hoslologox")!
        let tintImage = image.withRenderingMode(.alwaysOriginal)
        let logoImageView = UIImageView(image: tintImage)
      //  logoImageView.tintColor = .label
        //let logoImageView = UIImageView(image: #imageLiteral(resourceName: "logo"))
        logoImageView.contentMode = .scaleAspectFill
       
        return logoImageView
    }()
    
    
    
    
    
    
    
    
    
    
    
    
    
    

        let emailTextField: UITextField = {
            let tf = UITextField()
            tf.placeholder = "Email"
            tf.attributedPlaceholder = NSAttributedString(
                string: "Email",
                attributes: [NSAttributedString.Key.foregroundColor: UIColor.systemTeal]
            )
            tf.backgroundColor = .secondarySystemBackground
            tf.borderStyle = .roundedRect
            tf.font = UIFont.systemFont(ofSize: 14)
            tf.textColor = .label
            tf.addTarget(self, action: #selector(handleTextInputchange), for: .editingChanged)
            return tf
        }()
    private let facebookLoginButton: FBLoginButton = {
        let button = FBLoginButton()
        button.permissions = ["public_profile", "email"]
        return button
    }()

    private let googleLogInButton = GIDSignInButton()
    
    
    
    

        let passwordTextField: UITextField = {
            let tf = UITextField()
            tf.placeholder = "Password"
            tf.attributedPlaceholder = NSAttributedString(
                string: "Password",
                attributes: [NSAttributedString.Key.foregroundColor: UIColor.systemTeal]
            )
            tf.backgroundColor = .secondarySystemBackground
            tf.borderStyle = .roundedRect
            tf.textColor = .cyan
            tf.font = UIFont.systemFont(ofSize: 14)
            tf.isSecureTextEntry = true
            tf.addTarget(self, action: #selector(handleTextInputchange), for: .editingChanged)
            return tf
        }()
        
        @objc func handleTextInputchange() {
            let isFormValid = emailTextField.text?.count ?? 0 > 0
                && passwordTextField.text?.count ?? 0 > 0
            if isFormValid {
                loginButton.isEnabled = true
                loginButton.backgroundColor = .cyan
            } else {
                loginButton.isEnabled = false
                loginButton.backgroundColor = .cyan
            }
        }
        
        let loginButton: UIButton = {
            let button = UIButton(type: .system)
            button.setTitle("Login", for: .normal)
            button.backgroundColor = .cyan
            button.layer.cornerRadius = 5
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
            button.setTitleColor(.black, for: .normal)
            button.addTarget(self, action: #selector(handleLogin), for: .touchUpInside)
            button.isEnabled = false
            return button
        }()
        
        let dontHaveAccountButton: UIButton = {
            let button = UIButton(type: .system)
            let attributedTitle = NSMutableAttributedString(string: "Don't have an account?  ",
                                                            attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14),
                                                                         NSAttributedString.Key.foregroundColor: UIColor.lightGray])
            button.setAttributedTitle(attributedTitle, for: .normal)
            attributedTitle.append(NSAttributedString(string: "Sign Up.",
                                                      attributes: [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 14),
                                                                   NSAttributedString.Key.foregroundColor: UIColor.cyan]))
            button.addTarget(self, action: #selector(handleShowSignUp), for: .touchUpInside)
            return button
        }()

        override func viewDidLoad() {
            super.viewDidLoad()
            let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

                //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
                //tap.cancelsTouchesInView = false

                view.addGestureRecognizer(tap)
           //self.hideKeyboardWhenTappedAround()
            googleLogInButton.addTarget(self, action: #selector(googleSignInButtonTapped), for: .touchUpInside)
            facebookLoginButton.delegate = self
          //  view.backgroundColor = .systemBackground
            let collecol =   UIColor(red: 2/255.0, green: 28/255.0, blue: 34/255.0, alpha: 1)

            //collectionView?.backgroundColor = collecol
            view.backgroundColor = collecol
            navigationController?.navigationBar.isHidden = true
            setupLogoContainer()
            setupInputFields()
            setupDontHaveAccountButton()
        }
    @objc func dismissKeyboard() {
           view.endEditing(true)
       }
    
    
    @objc private func googleSignInButtonTapped() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate,
              let signInConfig = appDelegate.signInConfig else {
            return
        }
        GIDSignIn.sharedInstance.signIn(with: signInConfig, presenting: self) { user, error in
            guard let user = user, error == nil else { return }
            appDelegate.handleSessionRestore(user: user)
        }
        
            self.navigationController?.dismiss(animated: true, completion: nil)
        
        
        
    }
        
        fileprivate func setupLogoContainer() {
            view.addSubview(logoContrainerView)
            logoContrainerView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 150, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 150)
        }
        
        fileprivate func setupInputFields() {
            let stackView = UIStackView(arrangedSubviews: [emailTextField, passwordTextField, loginButton,facebookLoginButton,googleLogInButton])
            stackView.axis = .vertical
            stackView.spacing = 5
            stackView.distribution = .fillEqually
            view.addSubview(stackView)
            stackView.anchor(top: logoContrainerView.bottomAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, paddingTop: 40, paddingLeft: 40, paddingBottom: 0, paddingRight: 40, width: 0, height: 250)
        }
        
        fileprivate func setupDontHaveAccountButton() {
            view.addSubview(dontHaveAccountButton)
            dontHaveAccountButton.anchor(top: nil, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 20, paddingRight: 0, width: 0, height: 50)
            setupInputFields()
        }
   
    
        
        @objc
        func handleShowSignUp() {
            let signUpController = SignUpController()
            navigationController?.pushViewController(signUpController, animated: true)
        }
       
        @objc func handleLogin() {
            guard let email = emailTextField.text else { return }
            guard let password = passwordTextField.text else { return }
            
            
            
            
            
            UserDefaults.standard.set(email, forKey: "email")
            
            
            
            
            
            
            
            
            Auth.auth().signIn(withEmail: email, password: password) { (user, err) in
                if let error = err {
                    print("Failed to sign in with email:", error)
                    return
                }
            
                
                let safeEmail = DatabaseManager.safeEmail(emailAddress: email)
                DatabaseManager.shared.getDataFor(path: safeEmail, completion: { result in
                    switch result {
                    case .success(let data):
                        guard let userData = data as? [String: Any],
                            let firstName = userData["first_name"] as? String,
                            let lastName = userData["last_name"] as? String else {
                                return
                        }
                        UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")
                        
                        UserDefaults.standard.set(email, forKey: "email")
                     //   UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")
                        
                        
                        

                    case .failure(let error):
                        print("Failed to read data with error \(error)")
                    }
                })

              

                
                
                
                
                    self.navigationController?.dismiss(animated: true, completion: nil)
                
                
                
                
                
            }
            
            
            
            
            
            
            
            
            
        }

    }

extension LoginViewController: LoginButtonDelegate {
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        // no operation
    }

    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        guard let token = result?.token?.tokenString else {
            print("User failed to log in with facebook")
            return
        }

        let facebookRequest = FBSDKLoginKit.GraphRequest(graphPath: "me",
                                                         parameters: ["fields":
                                                            "email, first_name, last_name, picture.type(large)"],
                                                         tokenString: token,
                                                         version: nil,
                                                         httpMethod: .get)
        facebookRequest.start { _, result, error in
            guard let result = result as? [String: Any],
                error == nil else {
                    print("Failed to make facebook graph request")
                    return
            }
            print(result)
            guard let firstName = result["first_name"] as? String,
                let lastName = result["last_name"] as? String,
                let email = result["email"] as? String,
                let picture = result["picture"] as? [String: Any],
                let data = picture["data"] as? [String: Any],
                let pictureUrl = data["url"] as? String else {
                    print("Faield to get email and name from fb result")
                    return
            }
            UserDefaults.standard.set(email, forKey: "email")
            UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")
            let urllll = pictureUrl
       
            Auth.auth().hardcreateUser(with: email,
                                   username: firstName,
                                   password: "password",
                                   bio: "bio",
                                   image: urllll)
            { (err) in
                if let err = err {
                    print("Failed to sign up user:", err)
                  
                    return
                }
                
                let filename = urllll
                guard let url = URL(string: pictureUrl) else {
                    return
                }

                print("Downloading data from facebook image")

                URLSession.shared.dataTask(with: url, completionHandler: { data, _,_ in
                    guard let data = data else {
                        print("Failed to get data from facebook")
                        return
                    }
                StorageManager.shared.uploadProfilePicture(with: data, fileName: filename, completion: { result in
                    switch result {
                    case .success(let downloadUrl):
                        UserDefaults.standard.set(downloadUrl, forKey: "profile_picture_url")
                        print(downloadUrl)
                    case .failure(let error):
                        print("Storage maanger error: \(error)")
                    }
                })
            })
                
            }
            let credential = FacebookAuthProvider.credential(withAccessToken: token)
            FirebaseAuth.Auth.auth().signIn(with: credential, completion: { [weak self] authResult, error in
                guard let strongSelf = self else {
                    return
                }

                guard authResult != nil, error == nil else {
                    if let error = error {
                        print("Facebook credential login failed, MFA may be needed - \(error)")
                    }
                    return
                }

                print("Successfully logged user in")
                strongSelf.navigationController?.dismiss(animated: true, completion: nil)
            })
        }
    }

}

