//
//  profiecolleccel.swift
//  hoslo4
//
//  Created by Goktan on 15.05.2022.
//

import UIKit

class profiecolleccel: UICollectionViewCell {
    
    
    @IBOutlet weak var imagprocol: UIImageView!
    
    @IBOutlet weak var profileimagprocol: UIImageView!
    
    
    @IBOutlet weak var nameimagcel: UILabel!
    
    @IBOutlet weak var seenprocel: UILabel!
    @IBOutlet weak var likecountprocel: UILabel!
    
    
    
    
    func setupprocel(post:VideoPost){
        
        profileimagprocol.makeRounded(color: .white, borderWidth: 2)

        
        
     //   profilehomeimage..sd_setImage(with: URL(string: post.imageURL))
        likecountprocel.text = "\(post.likeCount)"
        seenprocel.text = "0"
      //  print(post.profileimageurl)
        print(URL(string: post.profileimageurl))
    
        profileimagprocol.sd_setImage(with: URL(string: post.profileimageurl))
        
        nameimagcel.text = post.username
        imagprocol.sd_setImage(with: URL(string: post.imageURL))
       
       
        
        
        
        
        
    }
}
