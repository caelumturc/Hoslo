//
//  VideoHomeViewController.swift
//  hoslo3
//
//  Created by Goktan on 25.04.2022.
//

import UIKit
import SnapKit
import AVFoundation
import RxSwift
import Lottie
import FirebaseAuth
import FirebaseDatabase


class VideoHomeViewController: UIViewController, UINavigationControllerDelegate, UIGestureRecognizerDelegate {
    
    
    var ultimateurl = URL(string: "DSFDSF")
    
    
    var mainTableView: UITableView!
    lazy var loadingAnimation: AnimationView = {
        let animationView = AnimationView(name: "LoadingAnimation")
        animationView.translatesAutoresizingMaskIntoConstraints = false
        animationView.contentMode = .scaleAspectFill
        animationView.animationSpeed = 0.8
        animationView.loopMode = .loop
        self.view.addSubview(animationView)
        self.view.bringSubviewToFront(animationView)
        animationView.snp.makeConstraints({make in
            make.center.equalToSuperview()
            make.width.height.equalTo(55)
        })
        return animationView
    }()
    
    // MARK: - Variables
    let cellId = "HomeCell"
    @objc dynamic var currentIndex = 0
    var oldAndNewIndices = (0,0)
    
    let viewModel = HomeViewModel()
    let disposeBag = DisposeBag()
    var data = [VideoPost]()
    var commentcoun = 0
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
      //  mainTableView.delegate = self
     //   mainTableView.dataSource = self
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
        viewModel.setAudioMode()
        setupView()
        setupBinding()
        setupObservers()

        // Do any additional setup after loading the view.
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let cell = mainTableView.visibleCells.first as? HomeTableViewCell {
            cell.play()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let cell = mainTableView.visibleCells.first as? HomeTableViewCell {
            cell.pause()
        }
    }
    
    /// Set up Views
    func setupView(){
        // Table View
        mainTableView = UITableView()
        mainTableView.backgroundColor = .black
        mainTableView.translatesAutoresizingMaskIntoConstraints = false  // Enable Auto Layout
        mainTableView.tableFooterView = UIView()
        mainTableView.isPagingEnabled = true
        mainTableView.contentInsetAdjustmentBehavior = .never
        mainTableView.showsVerticalScrollIndicator = false
        mainTableView.separatorStyle = .none
        view.addSubview(mainTableView)
        mainTableView.snp.makeConstraints({ make in
            make.edges.equalToSuperview()
        })
        mainTableView.register(UINib(nibName: "HomeTableViewCell", bundle: nil), forCellReuseIdentifier: cellId)
        mainTableView.delegate = self
        mainTableView.dataSource = self
        mainTableView.prefetchDataSource = self
    }

    /// Set up Binding
    func setupBinding(){
       
       
        print("merhaba")
        guard let uid = Auth.auth().currentUser?.uid else { return }
        print(uid)
      //  let ref = Database.database().reference().child("posts").child(uid)
        
        let ref = Database.database().reference().child("FeedPosts")
        
        
        
        
        
        
        

       // let ref = Database.database().reference()
        ref.observe(DataEventType.value, with: { snapshot in
      //  ref.queryOrdered(byChild: "").observe(.value, with: { snapshot in
            // Get user value
          //  let value = snapshot.value as? NSDictionary
         //     print(value)
         //     print("deneme1")
             // guard let dictionary = snapshot.value as? [String: Any] else { return }
     
      //      print("deneme2")
            
            
            for child in snapshot.children {
                let snap = child as! DataSnapshot
                
               

                print("deneme3")
                        
          //      let latitude = snap.childSnapshot(forPath: "latitude").value as! Double
                 // print(uid)
                let ayah = snap.key
                let ayaj = "\(ayah)"
                
           
                var commentCount = snap.childSnapshot(forPath: "commentCount").value as! Int
                let idd = snap.childSnapshot(forPath: "id").value as! String
                let imageUrl = snap.childSnapshot(forPath: "imageUrl").value as! String
                let shareCount = snap.childSnapshot(forPath: "shareCount").value as! Int
                let likeCount = snap.childSnapshot(forPath: "likeCount").value as! Int
                let video = snap.childSnapshot(forPath: "video").value as! String
                let videoFileExtennsion = snap.childSnapshot(forPath: "videoFileExtension").value as! String
                let videoURL = snap.childSnapshot(forPath: "videoURL").value as! String
                let videourlreallyurl = URL(string: videoURL)!
                print("ocococoocococ")
                print(videourlreallyurl)
             //   self.ultimateurl = videourlreallyurl
              //  print(self.ultimateurl)
                

                
                
              //  let visionCount = snap.childSnapshot(forPath: "visionCount").value as! Int
             //   let posstuser = snap.childSnapshot(forPath: "user").value as? [String:Any]
              //  print(posstuser)
           //     print(commentCount)
                 let  posstuser = snap.childSnapshot(forPath: "user").value as! [String:Any]
           let hasReadMessage = posstuser["bio "] as? String
                
           //     print(posstuser)//
           //     print(hasReadMessage)
                
            //    let user = User(uid: <#T##String#>, dictionary: <#T##[String : Any]#>)
                
             //   guard let userDic = dictionary["user"] as? [String: Any] else { return }
                let user = User(uid: posstuser["userId"] as! String, dictionary: posstuser)
                
                
                let eyeCount = snap.childSnapshot(forPath: "eyeCount").value as! Int
                
                
             //   print(posstuser["profileImageUrl"] as! String)
                
                
            
            let caption = snap.childSnapshot(forPath: "caption").value as! String
                
                let commentref = Database.database().reference().child("comments").child(idd)
                
                
                commentref.observe(DataEventType.value, with: { snapshot in
              //  ref.queryOrdered(byChild: "").observe(.value, with: { snapshot in
                    // Get user value
                  //  let value = snapshot.value as? NSDictionary
                 //     print(value)
                 //     print("deneme1")
                     // guard let dictionary = snapshot.value as? [String: Any] else { return }
             
              //      print("deneme2")
                    
                    
                    for child in snapshot.children {
                        let snap = child as! DataSnapshot
                        let video = snap.childSnapshot(forPath: "text").value as! String
                        self.commentcoun += 1
                
                      //  print(self.commentcoun)
                        commentCount = self.commentcoun
                      //  print(self.commentcoun)
                        
                        

                
                
                
                    }
                    
                  //  commentCount = self.commentcoun
             
                    
                    
                    self.data.removeAll(keepingCapacity: false)
                    
                    
                    let videopost = VideoPost(id: idd, video: video, useruid: posstuser["userId"] as! String, bio: posstuser["bio "] as! String, followcount: posstuser["followersCount"] as! Int, followingcount: posstuser["followingCount"] as! Int, postcount: posstuser["postsCount"] as! Int, profileimageurl: posstuser["profileImageUrl"] as! String, username: posstuser["username"] as! String, videoURL: videourlreallyurl, videoFileExtension: videoFileExtennsion, videoHeight: 1800, videoWidth: 900, autherID: "", autherName: "", caption: caption, commentCount: commentCount, eyeCount: eyeCount, music: "",likeCount:likeCount,shareCount:shareCount, imageURL: imageUrl, commentID: "")
                    
                
                   // let post = Post(user: user, dictionary:values)
                    print("atatarı")
                    print(videopost.videoURL)
                                       
                  
                    
                    self.data.append(videopost)
                   // print(videopost)
                 //   print("5")
                    
                    
                    
                    
                    self.mainTableView?.reloadData()
                    
                    
                    
                    
                    
                    
                    
                   
                })
             
                
                
                
                
            
               

                
            
    }
    
    

})
        
        
        
        // Posts
      
        
      
        
        viewModel.error
            .asObserver()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { err in
                self.showAlert(err.localizedDescription)
            }).disposed(by: disposeBag)
        
        ProfileViewModell.shared.cleardCache
            .asObserver()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { cleard in
                if cleard {
                    self.mainTableView.reloadData()
                }
            }).disposed(by: disposeBag)
    }
    
    func setupObservers(){
        
    }

}


// MARK: - Table View Extensions
extension VideoHomeViewController: UITableViewDelegate, UITableViewDataSource, UITableViewDataSourcePrefetching{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! HomeTableViewCell
        cell.configure(post: data[indexPath.row])
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // If the cell is the first cell in the tableview, the queuePlayer automatically starts.
        // If the cell will be displayed, pause the video until the drag on the scroll view is ended
        if let cell = cell as? HomeTableViewCell{
            oldAndNewIndices.1 = indexPath.row
            currentIndex = indexPath.row
            cell.pause()
        }
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // Pause the video if the cell is ended displaying
        if let cell = cell as? HomeTableViewCell {
            cell.pause()
        }
    }
    
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
//        for indexPath in indexPaths {
//            print(indexPath.row)
//        }
    }
    
    
}

// MARK: - ScrollView Extension
extension VideoHomeViewController: UIScrollViewDelegate {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        let cell = self.mainTableView.cellForRow(at: IndexPath(row: self.currentIndex, section: 0)) as? HomeTableViewCell
        cell?.replay()
    }
    
}

// MARK: - Navigation Delegate
// TODO: Customized Transition
extension VideoHomeViewController: HomeCellNavigationDelegate {
    func navigateToProfilePage(user:User ,name: String) {
       // userProfileController.user =
      //  UserProfileController
     //   UserProfileController().userId = uid
        
        
        
        
        
        let userProfileController = UserProfileController(collectionViewLayout: UICollectionViewFlowLayout())
        userProfileController.user = user
        userProfileController.userId = name
        
        
    //    let userProfileController = UserProfileController(collectionViewLayout: UICollectionViewFlowLayout())
        self.navigationController?.pushViewController(userProfileController, animated: true)
    }
    
    func navigateToComments(post:VideoPost){
        
        
        
        let commentsController = CommentsController(collectionViewLayout: UICollectionViewFlowLayout())
        commentsController.post = post
        commentsController.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(commentsController, animated: true)
    }
}

   


