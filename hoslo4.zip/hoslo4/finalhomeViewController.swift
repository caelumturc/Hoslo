//
//  finalhomeViewController.swift
//  hoslo3
//
//  Created by Goktan on 21.04.2022.
//

import UIKit
import FirebaseAuth
import Firebase
import SDWebImage


class finalhomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    var posts = [VideoPost]()
    var user:User?
    
    @IBOutlet weak var usersearchbutton: UIBarButtonItem!
    
    @IBOutlet weak var homeetableview: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        validateAuth()
        
        
        
        
        
        
        
        
        
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        Database.fetchUserWithUID(uid: uid) { (user) in
            self.user = user
            //self.navigationItem.title = self.user?.username
        }
      //  let mes = UIBarButtonItem(barButtonSystemItem: .bookmarks, target: self, action: #selector(messager))

        let search = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(gosearchg))
        search.tintColor = .white
        navigationItem.rightBarButtonItems = [search]
        
        loadhomedata()
        
        
        
        
        

           UserDefaults.standard.set(user?.username, forKey: "email")
     //   UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")
        
        
        
        
        
        
        
        
        homeetableview.delegate = self
        homeetableview.dataSource = self
        
        
        

        // Do any additional setup after loading the view.
    }
    private func validateAuth() {
        if FirebaseAuth.Auth.auth().currentUser == nil {
            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            present(nav, animated: false)
        }
    }

    func loadhomedata(){
        print("merhaba")
        guard let uid = Auth.auth().currentUser?.uid else { return }
        print(uid)
        let ref = Database.database().reference().child("FeedPosts")

       // let ref = Database.database().reference()
        ref.observe(DataEventType.value, with: { snapshot in
      //  ref.queryOrdered(byChild: "").observe(.value, with: { snapshot in
            // Get user value
          //  let value = snapshot.value as? NSDictionary
         //     print(value)
         //     print("deneme1")
             // guard let dictionary = snapshot.value as? [String: Any] else { return }
     
      //      print("deneme2")
            
            
            
            
            
            self.posts.removeAll(keepingCapacity: false)
            
            
            
            
            
            
            for child in snapshot.children {
                let snap = child as! DataSnapshot
                
                
                print("deneme3")
                        
          //      let latitude = snap.childSnapshot(forPath: "latitude").value as! Double
                 // print(uid)
                let ayah = snap.key
                let ayaj = "\(ayah)"
                
           
                let commentCount = snap.childSnapshot(forPath: "commentCount").value as! Int
                let idd = snap.childSnapshot(forPath: "id").value as! String
                let imageUrl = snap.childSnapshot(forPath: "imageUrl").value as! String
                let shareCount = snap.childSnapshot(forPath: "shareCount").value as! Int
                let likeCount = snap.childSnapshot(forPath: "likeCount").value as! Int
                
                let eyeCount = snap.childSnapshot(forPath: "eyeCount").value as! Int
               // let commentCount = snap.childSnapshot(forPath: "commentCount").value as! Int
                
                
                let video = snap.childSnapshot(forPath: "video").value as! String
                let videoFileExtennsion = snap.childSnapshot(forPath: "videoFileExtension").value as! String
                let videoURL = snap.childSnapshot(forPath: "videoURL").value as! String
                let videourlreallyurl = URL(string: videoURL)
              //  let visionCount = snap.childSnapshot(forPath: "visionCount").value as! Int
             //   let posstuser = snap.childSnapshot(forPath: "user").value as? [String:Any]
              //  print(posstuser)
           //     print(commentCount)
                 let  posstuser = snap.childSnapshot(forPath: "user").value as! [String:Any] 
                 let hasReadMessage = posstuser["bio "] as? String
                
           //     print(posstuser)//
           //     print(hasReadMessage)
                
            //    let user = User(uid: <#T##String#>, dictionary: <#T##[String : Any]#>)
                
             //   guard let userDic = dictionary["user"] as? [String: Any] else { return }
                let user = User(uid: posstuser["userId"] as! String, dictionary: posstuser)
                
                
                
                
                
             //   print(posstuser["profileImageUrl"] as! String)
                
                
            
            let caption = snap.childSnapshot(forPath: "caption").value as! String
                
                
                
                
                
                
                let videopost = VideoPost(id: idd, video: video, useruid: posstuser["userId"] as! String, bio: posstuser["bio "] as! String, followcount: posstuser["followersCount"] as! Int, followingcount: posstuser["followingCount"] as! Int, postcount: posstuser["postsCount"] as! Int, profileimageurl: posstuser["profileImageUrl"] as! String, username: posstuser["username"] as! String, videoURL: videourlreallyurl, videoFileExtension: videoFileExtennsion, videoHeight: 1800, videoWidth: 900, autherID: "", autherName: "", caption: caption, commentCount: commentCount, eyeCount: eyeCount, music: "",likeCount:likeCount,shareCount:shareCount, imageURL: imageUrl, commentID: "")
                
                
            
               // let post = Post(user: user, dictionary:values)
                self.posts.append(videopost)
                
                
                
                
                
                
                
                
                
               // print(videopost)
             //   print("5")
                
                self.homeetableview?.reloadData()
            
    }
    
    

})
           
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "finalhomecell", for: indexPath) as! finalhomeTableViewCell
        cell.setup(post: posts[indexPath.row])
        
        
        
        
        
        
        
     //   let gesture = UITapGestureRecognizer(target: self,
                                                 // action: #selector(handledetal))
              
              
              
              

              
              
       // cell.imagcecellView.addGestureRecognizer(gesture)
        
       // cell.descriptioncelllabel.text = posts[indexPath.row].description
       
            return cell
        
        
        
        
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {

       return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 350
    }
    
    
 //   @IBAction func searchviewgo(_ sender: Any) {

        
    @objc func gosearchg(){
            
            print("basildi")
            
            let userSearch = UserSearchController(collectionViewLayout: UICollectionViewFlowLayout())
           
            
            
        //    let userProfileController = UserProfileController(collectionViewLayout: UICollectionViewFlowLayout())
            self.navigationController?.pushViewController(userSearch, animated: true)
            
        }
       
    @objc func messager(){
            
      
            
        }
       
    
    
        
        
        
        
    }
    
    
    
    
    
    
    

