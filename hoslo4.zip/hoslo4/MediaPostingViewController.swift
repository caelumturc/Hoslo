//
//  PostMediaViewController.swift
//  KD Tiktok-Clone
//
//  Created by Sam Ding on 10/3/20.
//  Copyright © 2020 Kaishan. All rights reserved.
//

import UIKit
import JGProgressHUD
import Firebase



@testable import RxSwift

class MediaPostingViewController: UIViewController, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    let cameraManager = CameraManager()
    private let spinner = JGProgressHUD(style: .dark)
    var User:User?
    var ui:String = ""
    
    var myuserdic:[String:Any] = ["A":2]
    

    // MARK: - UI Components
    @IBOutlet weak var captionTextView: UITextView!
    var placeholderLabel : UILabel!
    @IBOutlet weak var coverImgView: UIImageView!
    @IBOutlet weak var postBtn: UIView!{
        didSet{
            let postGesture = UITapGestureRecognizer(target: self, action: #selector(publishPost))
            postBtn.addGestureRecognizer(postGesture)
        }
    }
    
    // MARK: - Variables
    var videoURL: URL?
    var StringvideoURL:String = ""
    
    // MARK: - Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        coverImgView.isUserInteractionEnabled = true
    //    scrollView.isUserInteractionEnabled = true

        let gesture = UITapGestureRecognizer(target: self,
                                             action: #selector(handlePlusPhoto))
        coverImgView.addGestureRecognizer(gesture)
        
        
      //  coverImgView.addTarget(self, action: #selector(handlePlusPhoto), for: .touchUpInside)
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    // MARK: - Setup
    func setupView(){
        let dismissKeybordGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(dismissKeybordGesture)
        
        // Add placeholder
        captionTextView.delegate = self
        placeholderLabel = UILabel()
        placeholderLabel.text = "Describe your video"
        placeholderLabel.font = UIFont.systemFont(ofSize: (captionTextView.font?.pointSize)!)
        placeholderLabel.sizeToFit()
        captionTextView.addSubview(placeholderLabel)
        placeholderLabel.frame.origin = CGPoint(x: 5, y: (captionTextView.font?.pointSize)! / 2)
        placeholderLabel.textColor = UIColor.lightGray
        placeholderLabel.isHidden = !captionTextView.text.isEmpty
        
    }
    
    @objc func dismissKeyboard(){
        captionTextView.endEditing(true)
    }
    
    func textViewDidChange(_ textView: UITextView) {
        placeholderLabel.isHidden = !textView.text.isEmpty
    }
    func randomString(length: Int) -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<length).map{ _ in letters.randomElement()! })
    }
    
    func randomNumber(min: Int, max: Int) -> Int {
        return Int.random(in: min...max)
    }
    
    @objc func publishPost(){
        // Disable the buttion to prevent duplicate posts
        
        
        postBtn.isUserInteractionEnabled = false
        spinner.show(in: view)
      
        
        guard let image = coverImgView.image else { return }
        guard let uploadData = image.jpegData(compressionQuality: 0.2) else { return }
        navigationItem.rightBarButtonItem?.isEnabled = false
        let filename = NSUUID().uuidString
        let storageRef = Storage.storage().reference().child("posts").child(filename)
        storageRef.putData(uploadData, metadata: nil) { (metadata, err) in
            if let err = err {
              //  self.navigationItem.rightBarButtonItem?.isEnabled = true
                print("Failed to upload post image:", err)
                return
            }
            storageRef.downloadURL(completion: { (downloadURL, err) in
                if let err = err {
                    print("Failed to fetch downloadURL:", err)
                    return
                }
                guard let imageUrl = downloadURL?.absoluteString else { return }
                
                let bacak = "\(downloadURL)"
            
                
                print("Successfully uploaded post image:", imageUrl)
                self.ui = bacak
                
              //  print(url)
               // print(self.StringvideoURL)
              //  print(self.ui)
                
                self.loaddata(imageurl: imageUrl)
            })
        }
        
     //   self.spinner.dismiss(animated: false)
        
        
        
        
        
        
       

      //  if let url = videoURL {
        //    print(url)
            
            
     //       let caption = captionTextView.text ?? ""
      //      print(caption)
        //    guard let uid = Auth.auth().currentUser?.uid else { return }
            
          //  Database.fetchUserWithUID(uid: uid) { user in
               // let userDic:[String: Any] = ["userId": uid,
                    //                         "bio ": user.bio,
                    //                         "followersCount": user.followersCount,
                     //                        "followingCount": user.followingCount,
                     //                        "postsCount": user.postsCount,
                      //                       "profileImageUrl": user.profileImageUrl,
                      //                       "username": user.username
                      //                      ]
                //values["user"] = userDic
               // feedPostRefperUser.child(key).childByAutoId().updateChildValues(values)
             //   self.User = user
         //   }
            
            
       //     print(self.User)
            
            
            
            
      //      guard let image = coverImgView.image else { return }
            
            
          //  print("3")
       //     guard let uploadData = image.jpegData(compressionQuality: 0.2) else { return }
           // print("4")
         //   navigationItem.rightBarButtonItem?.isEnabled = false
          //  print("5")
    //        let filename = NSUUID().uuidString
    //        let storageRef = Storage.storage().reference().child("posts").child(filename)
         //   print("2")
            //allta olabşkrş
          //  print(caption)
        //    storageRef.putData(uploadData, metadata: nil) { (metadata, err) in
           //     if let err = err {
           //         self.navigationItem.rightBarButtonItem?.isEnabled = true
           //         print("Failed to upload post image:", err)
             //       return
           //     }
             //  storageRef.downloadURL(completion: { (downloadURL, err) in
                  //  if let err = err {
                  //      print("Failed to fetch downloadURL:", err)
                  //      return
                  //  }
                  //  guard let imageurl = downloadURL?.absoluteString else { return }
                   // self.ui = imageurl
                 //   print("Successfully uploaded post image:", imageUrl)
                  
             //   })
      //      }
            
            
            
            
          //  guard let gubio = User?.bio else { return }
          //  guard let guflww = User?.followersCount else { return }
         //   guard let fuflwwi = User?.followingCount else { return }
         //   guard let gupost = User?.postsCount else { return }
        //    guard let guprofileimagurl = User?.profileImageUrl else { return }
       //     guard let guusername = User?.username else { return }
           
            
            
            
            
            
            
            
         //   MediaViewModel.shared.postVideo(videoURL: url, //imageURL:self//.ui,useruid:uid,bio:gubio,followcount:guflww,followingcount:fuflwwi,postcount:gupost//,profileimageurl:guprofileimagurl,username:guusername, caption: caption, success: { message in
            //    print(message)
                
       //         print(guusername)
         //       print(guprofileimagurl)
                
            //    self.postBtn.isUserInteractionEnabled = true
                
                
              //  self.dismiss(animated: true, completion: nil)
                
              //  self.spinner.dismiss()
                
                
                
        //    }, failure: { error in
          //      self.showAlert(error.localizedDescription)
                
          //  })
      //  }
    }
    
    
    func loaddata(imageurl:String){
        
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let caption = captionTextView.text else {return}
        guard let url = videoURL else { return }
        let videoName = randomString(length: 10) + ".\(VIDEO_FILE_EXTENSION)"
        // TODO: Edit the other field of the post
        
        
   //     print(url)
        
        let postID = UUID()
        let StringPostID = "\(postID)"
        
        
        let userPostRef = Database.database().reference().child("posts").child(uid)
        let ref = userPostRef.childByAutoId()
        
        
      
        
        self.StringvideoURL = url.absoluteString
     //   print(url)
     //   print(self.ui)
        
       
        let asdas = StringvideoURL
        
        
        
        
      //  let post = VideoPost(id: StringPostID, video: videoName, videoURL: videoURL,imageURL:imageURL,videoFileExtension: VIDEO_FILE_EXTENSION, videoHeight: 1800, videoWidth: 900, caption: caption, likeCount: 0, shareCount:0,commentCount:0,visionCount:0)
         
       // print(ui)
        
       
        
        
        
        var values = ["imageUrl":imageurl, "caption": caption,"id":StringPostID,"videoURL":asdas,"video":videoName,"videoFileExtension":VIDEO_FILE_EXTENSION,"likeCount":0,"shareCount":0,"commentCount":0,"eyeCount":0,"user":myuserdic,"videoHeight": 1800, "videoWidth": 900] as [String : Any]
        
        
        
        
        Database.fetchUserWithUID(uid: uid) { user in
            let userDic:[String: Any] = ["userId": uid,
                                         "bio ": user.bio,
                                         "followersCount": user.followersCount,
                                         "followingCount": user.followingCount,
                                         "postsCount": user.postsCount,
                                         "profileImageUrl": user.profileImageUrl,
                                         "username": user.username
                                        ]
            
           
            
            
            
            values["user"] = userDic
            
            ref.updateChildValues(values) { (err, ref) in
                if let err = err {
                   // self.navigationItem.rightBarButtonItem?.isEnabled = true
                    print("Failed to save post to DB", err)
                    return
                }
                print("Successfully saved post to DB")
                
                
                
                
                
                
                self.spinner.dismiss(animated: true)
                
             
                let alert = UIAlertController(title: "Succes", message: "successfully shared",         preferredStyle: UIAlertController.Style.alert)

                alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
                            //Cancel Action
                        }))
                        
                        self.present(alert, animated: true, completion: nil)
                
                
                
               // self.navigationController?.pushViewController(VideoHomeViewController(), animated: true)
               // self.cameraManager.removeAllTempFiles()
                
               self.dismiss(animated: true, completion: nil)
               // NotificationCenter.default.post(name: SharePhotoController.updateFeedNotificationName, object: nil)
            }
            
            
          //  feedPostRefperUser.child(key).updateChildValues(values)
        }
        
        
        
        
       
        print(uid)
      //  print(User?.username)
        
        
        
        // update user profile info
        let userRef = Database.database().reference().child("users").child(uid)
        Database.fetchUserWithUID(uid: uid) { user in
            userRef.updateChildValues(["postsCount": user.postsCount+1])
            print(user.username)
        }
        // update feed posts
        let feedPostRefperUser = Database.database().reference().child("FeedPost").child(uid)
       // let followersRef = Database.database().reference().child("followers").child(uid)
        //flowwersref yerine feed  yazdık asağıda
        
        feedPostRefperUser.observeSingleEvent(of: .value) { snapshot,error in
            
            if error != nil{
                print("hata")
            }
            guard let dictionary = snapshot.value as? [String: Int] else { return }
           dictionary.forEach { (key, value) in
               
               //let userDic = [uid: ]
               //feedPostRefperUser.child(key).childByAutoId().updateChildValues(values)
               Database.fetchUserWithUID(uid: uid) { user in
                   let userDic:[String: Any] = ["userId": uid,
                                                "bio ": user.bio,
                                                "followersCount": user.followersCount,
                                                "followingCount": user.followingCount,
                                                "postsCount": user.postsCount,
                                                "profileImageUrl": user.profileImageUrl,
                                                "username": user.username
                                               ]
                   
                   
                   values["user"] = userDic
                   feedPostRefperUser.child(key).updateChildValues(values)
               }
           }
            
            
            
        }
      
        
        
          // feedPostRefperUser.observeSingleEvent(of: .value) { snapshot in
          //   guard let dictionary = snapshot.value as? [String: Int] else { return }
         //   dictionary.forEach { (key, value) in
                
                //let userDic = [uid: ]
                //feedPostRefperUser.child(key).childByAutoId().updateChildValues(values)
          //      Database.fetchUserWithUID(uid: uid) { user in
            //        let userDic:[String: Any] = ["userId": uid,
           //                                      "bio ": user.bio,
          //                                       "followersCount": user.followersCount,
          //                                       "followingCount": user.followingCount,
         //                                        "postsCount": user.postsCount,
          //                                       "profileImageUrl": user.profileImageUrl,
         //                                        "username": user.username
           //                                     ]
           //         print(user.username)
                    
            //        values["user"] = userDic
            //        feedPostRefperUser.child(key).childByAutoId().updateChildValues(values)
           //     }
         //   }
            
    //    }
        
        
       // let all = Database.database().reference().child("FeedPosts").childByAutoId()
        
        let all = Database.database().reference().child("FeedPosts").child(StringPostID)

        
    
            
            
            Database.fetchUserWithUID(uid: uid) { user in
                let userDic:[String: Any] = ["userId": uid,
                                             "bio ": user.bio,
                                             "followersCount": user.followersCount,
                                             "followingCount": user.followingCount,
                                             "postsCount": user.postsCount,
                                             "profileImageUrl": user.profileImageUrl,
                                             "username": user.username
                                            ]
                values["user"] = userDic
                
                
                
                all.updateChildValues(values) { (err, ref) in
                            if let err = err {
                              ///  self.navigationItem.rightBarButtonItem?.isEnabled = true
                                print("Failed to save post to DB", err)
                                return
                            }
                    
                    print("Successfully saved post to DB")
                
                
            }
            
            
            
                
                 //   self.dismiss(animated: true, completion: nil)
                 //   NotificationCenter.default.post(name: AddindPostViewController.updateFeedNotificationName, object: nil)
                }
        
        
        
        
        
        
        
        
    }
    
    
    
    @objc func handlePlusPhoto() {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let editedImage = info[.editedImage] as? UIImage {
            
           // coverImgView.setImage(editedImage.withRenderingMode(.alwaysOriginal), for: .normal)
            
            coverImgView.image = editedImage
        } else if let originalImage = info[.originalImage] as? UIImage {
          //  coverImgView.setImage(originalImage.withRenderingMode(.alwaysOriginal), for: .normal)
            
            coverImgView.image = originalImage
        }

      //  photoButton.layer.cornerRadius = photoButton.frame.width / 2
      // photoButton.layer.masksToBounds = true

        dismiss(animated: true, completion: nil)
    }
    
    
    
}
