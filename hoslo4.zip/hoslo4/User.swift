//
//  User.swift
//  Instagram_Clone_SW5
//
//  Created by Abdalla Elsaman on 11/24/19.
//  Copyright © 2019 Dumbies. All rights reserved.
//


import Foundation

struct User {
    let uid: String
    let username: String
    let profileImageUrl: String
    let bio: String
    var followingCount: Int
    var followersCount: Int
    var postsCount: Int

    init(uid: String, dictionary: [String: Any]) {
        self.uid = uid
        username = dictionary["username"] as? String ?? ""
        profileImageUrl = dictionary["profileImageUrl"] as? String ?? ""
        bio = dictionary["bio"] as? String ?? ""
        followingCount = dictionary["followingCount"] as? Int ?? 0
        followersCount = dictionary["followersCount"] as? Int ?? 0
        postsCount = dictionary["postsCount"] as? Int ?? 0
    }

}

import Foundation
import UIKit

struct Userrr {
    var uid: String
    var name: String
    var description: String
    var douyinID: Int
    var tags: [String]
    var profilePic: String
    var posts: [String]
    var likedPosts: [String]
    var followerCount: Int
    var followCount: Int
    var likeCount: Int
    var friendsCount: Int
}


