//
//  finalprof.swift
//  hoslo4
//
//  Created by Goktan on 17.05.2022.
//

import UIKit
import Firebase
import FBSDKLoginKit
import GoogleSignIn

class finalprof: UIViewController , UITableViewDelegate, UITableViewDataSource    {
    
    
    var user: User?
    var posts = [VideoPost]()
    var userId: String?
   
    
    var isGridView: Bool = true
    
    @IBOutlet weak var profinaltable: UITableView!
    
    @IBOutlet weak var profileimagfinal: UIImageView!
    
    @IBOutlet weak var namelabelfinal: UILabel!
    
    @IBOutlet weak var biofinalpro: UILabel!
    
    
    @IBOutlet weak var followprof: UIButton!
    
    @IBOutlet weak var postslabelpro: UILabel!
    
    @IBOutlet weak var followlabelpro: UILabel!
    
    
    @IBOutlet weak var followingl: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let collecol =   UIColor(red: 2/255.0, green: 28/255.0, blue: 34/255.0, alpha: 1)

        profinaltable?.backgroundColor = collecol
        
        
        setupLogOutButton()
        fetchUser()
        
        
        

        // Do any additional setup after loading the view.
    }
    fileprivate func fetchUser() {
        let uid = userId ?? (Auth.auth().currentUser?.uid ?? "")
        
        Database.database().reference().child("users").child(uid).observe( .value) { [self] snapshot in
            guard let userDictionary = snapshot.value as? [String: Any] else { return }
            let user = User(uid: uid, dictionary: userDictionary)
            self.user = user
            self.navigationItem.title = self.user?.username
            
            
            guard let profileImageUrl = self.user?.profileImageUrl else { return }
           // profileimagfinal.loadImage(urlString: profileImageUrl)
            self.profileimagfinal.sd_setImage(with: URL(string: user.profileImageUrl))
            
            self.namelabelfinal.text = self.user?.username
            self.biofinalpro.text = self.user?.bio
          //  delegate?.setupHeaderEditFollowButton(for: self)
            //setupEditFollowButton()
          //  setupFollowingAndFollowersButton()
            
            
            
            
            
            
            
            
            
         
             //self.collectionView?.reloadData()
            self.profinaltable.reloadData()
            self.fetchOrderedPosts()
        }
    }
    
    fileprivate func fetchOrderedPosts() {
        guard let uid = user?.uid else { return }
        let ref = Database.database().reference().child("posts").child(uid)
        self.posts.removeAll(keepingCapacity: false)
        
        
        ref.queryOrdered(byChild: "creationDate").observe(.childAdded, with: { (snapshot) in
            guard let dictionary = snapshot.value as? [String: Any] else { return }
            guard let user = self.user else { return }
            
            print("PROFİL DENEMESİ")
            let post = VideoPost(dictionary: dictionary)
            print(post)
            
           
          //  let post = Post(user: user, dictionary: dictionary)
            self.posts.append(post)
            self.profinaltable.reloadData()        }) { (err) in
            print("Failed to fetch ordered posts:", err)
        }
    }
    
    fileprivate func setupLogOutButton() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "list.dash")?.withTintColor(.label,
                                                                                                                   renderingMode: .alwaysOriginal),
                                                            style: .plain,
                                                            target: self,
                                                            action: #selector(handleLogOut))
    }
    
    
    
    
    
    @objc func handleLogOut() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alertController.addAction(UIAlertAction(title: "Log Out", style: .destructive, handler: { (_) in
            
            
            
            
            FBSDKLoginKit.LoginManager().logOut()
            GIDSignIn.sharedInstance.signOut()
            
            
            do {
                try Auth.auth().signOut()
                let loginController = LoginViewController()
                let navController = UINavigationController(rootViewController: loginController)
                navController.modalPresentationStyle = .fullScreen
                self.present(navController, animated: true, completion: nil)
            } catch let signOutErr {
                print("Failed to sign out:", signOutErr)
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "Notifications", style: .default, handler: { (_) in
            
            self.performSegue(withIdentifier: "notification", sender: nil)

            
       
        }))
        
        alertController.addAction(UIAlertAction(title: "Messages", style: .default, handler: { (_) in
            
            self.performSegue(withIdentifier: "conversation", sender: nil)
            
          
        }))
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "finalhomecell", for: indexPath) as! finalhomeTableViewCell
        cell.setup(post: posts[indexPath.row])
        
        
        
        
        
        
        
     //   let gesture = UITapGestureRecognizer(target: self,
                                                 // action: #selector(handledetal))
              
              
              
              

              
              
       // cell.imagcecellView.addGestureRecognizer(gesture)
        
       // cell.descriptioncelllabel.text = posts[indexPath.row].description
       
            return cell
        
        
        
        
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {

       return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 350
    }
    
    func setupHeaderEditFollowButtonmyprofe() {
        guard let currentLoggedInUserId = Auth.auth().currentUser?.uid else { return }
        guard let userId = user?.uid else { return }
        
        if currentLoggedInUserId == userId {
            //edit
            self.followprof.setTitle("Edit Profile", for: .normal)
        } else {
            // check if following
            Database.database().reference().child("following").child(currentLoggedInUserId).child(userId).observeSingleEvent(of: .value, with: { (snapshot) in
                if let isFollowing = snapshot.value as? Int, isFollowing == 1 {
                    self.followprof.setTitle("Unfollow", for: .normal)
                } else {
                 //   header.setupFollowStyle()
                }
            }) { (err) in
                print("Failed to check if following:", err)
            }
        }
    }
    
    
 //   @IBAction func searchviewgo(_ sender: Any) {

        
    @objc func gosearchg(){
            
            print("basildi")
            
            let userSearch = UserSearchController(collectionViewLayout: UICollectionViewFlowLayout())
           
            
            
        //    let userProfileController = UserProfileController(collectionViewLayout: UICollectionViewFlowLayout())
            self.navigationController?.pushViewController(userSearch, animated: true)
            
        }
       
    @objc func messager(){
            
      
            
        }

}
