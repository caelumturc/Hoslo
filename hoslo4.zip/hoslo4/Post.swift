//
//  Post.swift
//  Instagram_Clone_SW5
//
//  Created by Abdalla Elsaman on 11/25/19.
//  Copyright © 2019 Dumbies. All rights reserved.
//import Foundation



import Foundation

struct Post {
    
    var id: String?
    let user: User
    let imageUrl: String
    let caption: String
    let creationDate: Date
    var hasLiked = false
    
    
    
    init(user: User, dictionary: [String: Any]) {
        self.user = user
        self.imageUrl = dictionary["imageUrl"] as? String ?? ""
        self.caption = dictionary["caption"] as? String ?? ""
        let secondsFrom1970 = dictionary["creationDate"] as? Double ?? 0
        self.creationDate = Date(timeIntervalSince1970: secondsFrom1970)
        hasLiked = dictionary["hasLiked"] as? Bool ?? false
    }
}
struct VideoPost: Codable{
    

    
    
    
    
    
    
    
    
    var id: String
    var video: String
    var videoURL: URL?
    var videoFileExtension: String?
    var videoHeight: Int
    var videoWidth: Int
    var autherID: String
    var autherName: String
    var caption: String
    var music: String
    var likeCount: Int
    var eyeCount: Int
    var commentCount: Int
    var shareCount: Int
    var commentID: String
    var imageURL:String
    var useruid:String
    var bio:String
    var followcount:Int
    var followingcount:Int
    var postcount:Int
    var profileimageurl:String
    var username:String
    

    
    //var user:User
    
    
    
    enum CodingKeys: String, CodingKey {
        case id
        case video
        case videoURL
        case videoFileExtension
        case videoHeight
        case videoWidth
        case autherID = "author"
        case autherName
        case caption
        case music
        case commentCount
        case eyeCount
        case likeCount
        case shareCount
        case commentID
        case imageURL
        case useruid
        case bio
        case followcount
        case followingcount
        case postcount
        case profileimageurl
        case username
        
    }
    
    init(id: String, video: String,useruid:String,bio:String,followcount:Int,followingcount:Int,postcount:Int,profileimageurl:String,username:String, videoURL: URL? = nil, videoFileExtension: String? = nil, videoHeight: Int, videoWidth: Int, autherID: String, autherName: String, caption: String,commentCount:Int ,eyeCount:Int,music: String, likeCount: Int, shareCount: Int,imageURL: String, commentID: String) {
        self.id = id
        self.video = video
        self.videoURL = videoURL ?? URL(fileURLWithPath: "")
        self.videoFileExtension = videoFileExtension ?? "mp4"
        self.videoHeight = videoHeight
        self.videoWidth = videoWidth
        self.autherID = autherID
        self.autherName = autherName
        self.caption = caption
        self.music = music
        self.likeCount = likeCount
        self.shareCount = shareCount
        self.imageURL = imageURL
        self.commentID = commentID
        self.username = username
        self.followcount = followcount
        self.bio = bio
        self.profileimageurl = profileimageurl
        self.followingcount = followingcount
        self.postcount = postcount
        self.useruid = useruid
        self.commentCount = commentCount
        self.eyeCount = eyeCount
        
       // self.user = user
    }
    
    init(dictionary: [String: Any]) {
        id = dictionary["id"] as? String ?? ""
        video = dictionary["video"] as? String ?? ""
        let urlString = dictionary["videoURL"] as? String ?? ""
        videoURL = URL(string: urlString)
        videoFileExtension = dictionary["videoFileExtension"] as? String ?? ""
        videoHeight = dictionary["videoHeight"] as? Int ?? 0
        videoWidth = dictionary["videoWidth"] as? Int ?? 0
        autherID = dictionary["author"] as? String ?? ""
        autherName = dictionary["autherName"] as? String ?? ""
        caption = dictionary["caption"] as? String ?? ""
        music = dictionary["music"] as? String ?? ""
        likeCount = dictionary["likeCount"] as? Int ?? 0
        shareCount = dictionary["shareCount"] as? Int ?? 0
        eyeCount = dictionary["eyeCount"] as? Int ?? 0
        commentCount = dictionary["commentCount"] as? Int ?? 0
        commentID = dictionary["commentID"] as? String ?? ""
        imageURL = dictionary["imageURL"] as? String ?? ""
        username = dictionary["username"] as? String ?? ""
        followcount = dictionary["followcount"] as? Int ?? 0
        followingcount = dictionary["followingcount"] as? Int ?? 0
        bio = dictionary["bio"] as? String ?? ""
        profileimageurl = dictionary["profileimageurl"] as? String ?? ""
        useruid = dictionary["useruid"] as? String ?? ""
        postcount = dictionary["postcount"] as? Int ?? 0
        
       
        
        
     //   user = dictionary["user"] as? User ?? User(uid: "", dictionary: ["String" : "Any"])
        //user = dictionary["user"] as? User ?? User(uid: "", dictionary: ["String" : "Any"])
    }

    
    var dictionary: [String: Any] {
        let data = (try? JSONEncoder().encode(self)) ?? Data()
        return (try? JSONSerialization.jsonObject(with: data, options: [.mutableContainers, .allowFragments]) as? [String: Any]) ?? [:]
    }
    
}

