//
//  finalhomeTableViewCell.swift
//  hoslo3
//
//  Created by Goktan on 21.04.2022.
//

import UIKit
import SDWebImage

class finalhomeTableViewCell: UITableViewCell {

    @IBOutlet weak var imageViewHome: UIImageView!
    @IBOutlet weak var profilehomeimage: UIImageView!
    
    
    
    @IBOutlet weak var likehome: UIImageView!
    
    @IBOutlet weak var usernamehome: UILabel!
    
    @IBOutlet weak var eyehome: UIImageView!
    
    @IBOutlet weak var eyecounthome: UILabel!
    @IBOutlet weak var likecounthome: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setup(post:VideoPost){
        
        profilehomeimage.makeRounded(color: .white, borderWidth: 2)

        
        
     //   profilehomeimage..sd_setImage(with: URL(string: post.imageURL))
        likecounthome.text = "\(post.likeCount)"
        eyecounthome.text = "0"
      //  print(post.profileimageurl)
        print(URL(string: post.profileimageurl))
    
        profilehomeimage.sd_setImage(with: URL(string: post.profileimageurl))
        
        usernamehome.text = post.username
        imageViewHome.sd_setImage(with: URL(string: post.imageURL))
       
       
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
