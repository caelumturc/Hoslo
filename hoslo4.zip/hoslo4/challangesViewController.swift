//
//  challangesViewController.swift
//  hoslo4
//
//  Created by Goktan on 6.05.2022.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class challangesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var challengestab: UITableView!
    
    
    var challanges = [Comment]()

    override func viewDidLoad() {
        super.viewDidLoad()
        let collecol =   UIColor(red: 2/255.0, green: 28/255.0, blue: 34/255.0, alpha: 1)
        challengestab.backgroundColor = collecol
        
        challengestab.delegate = self
        challengestab.dataSource = self
        fetchChallenges()


        // Do any additional setup after loading the view.
    }
    func fetchChallenges(){
        
        
        guard let uuid = Auth.auth().currentUser?.uid else { return }
         print(uuid)
        
     //   print(uuid)
        
        
        
        let ref = Database.database().reference().child("challanges").child(uuid)
         
        ref.observe(.childAdded, with: { (snapshot) in
           guard let dictionary = snapshot.value as? [String: Any] else { return }
           guard let uid = dictionary["uid"] as? String else { return }
           Database.fetchUserWithUID(uid: uid, completion: { (user) in
               
               
               let challange = Comment(user: user, dictionary: dictionary)
               self.challanges.append(challange)
               self.challengestab?.reloadData()

               
            //   print(self.comments)
            //   print(dictionary)
               
               
              //print(uid)

         //      self.notifitable?.reloadData()
       })
       }) { (err) in
           print("Failed to observe comments")
       }
        
        
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        challanges.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "challangecell", for: indexPath) as! challengescell
        
       
        
        cell.setuppp(challange: challanges[indexPath.row])
        
        
        
        
        
        
        
        
     //   let gesture = UITapGestureRecognizer(target: self,
                                                 // action: #selector(handledetal))
              
              
              
              

              
              
       // cell.imagcecellView.addGestureRecognizer(gesture)
        
       // cell.descriptioncelllabel.text = posts[indexPath.row].description
       
            return cell
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {

       return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
