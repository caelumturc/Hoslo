//
//  NotificationsViewController.swift
//  hoslo4
//
//  Created by Goktan on 4.05.2022.
//

import UIKit
import Firebase
import FirebaseAuth

class NotificationsViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    
    @IBOutlet weak var notifitable: UITableView!
    
    
    var comments = [Comment]()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        notifitable.delegate = self
        notifitable.dataSource = self
        
        
        fetchNotificitins()

        // Do any additional setup after loading the view.
    }
    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
     func fetchNotificitins() {
        guard let uuid = Auth.auth().currentUser?.uid else { return }
         print(uuid)
        
     //   print(uuid)
        
        
        
        let ref = Database.database().reference().child("notifications").child(uuid)
         
      //   ref.observe(DataEventType.value, with: { snapshot in

         
         
         
         
         ref.observe(.childAdded, with: { (snapshot) in
            guard let dictionary = snapshot.value as? [String: Any] else { return }
            guard let uid = dictionary["uid"] as? String else { return }
            Database.fetchUserWithUID(uid: uid, completion: { (user) in
                
                
                let comment = Comment(user: user, dictionary: dictionary)
                self.comments.append(comment)
                self.notifitable?.reloadData()

                print(self.comments)
                
               // print(self.comments)
              
             //   print(self.comments)
             //   print(dictionary)
                
                
               //print(uid)

          //      self.notifitable?.reloadData()
        })
        }) { (err) in
            print("Failed to observe comments")
        }
         

         
         
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        comments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "notificationcell", for: indexPath) as! NotificationsCelll
        
        print(comments[indexPath.row].text)
        
        
        
        cell.setupp(notifi: comments[indexPath.row])
        
        
        
        
        
        
        
     //   let gesture = UITapGestureRecognizer(target: self,
                                                 // action: #selector(handledetal))
              
              
              
              

              
              
       // cell.imagcecellView.addGestureRecognizer(gesture)
        
       // cell.descriptioncelllabel.text = posts[indexPath.row].description
       
            return cell
        
        
        
        
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {

       return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
